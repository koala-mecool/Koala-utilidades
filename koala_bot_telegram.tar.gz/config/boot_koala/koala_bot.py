#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
sys.path.extend(["/storage/.opt/lib/python2.7/site-packages/"])
import telebot
from telebot import types
import time
import os
import commands

 
BOT_TOKEN = "mi token"

CHAT_ID = mi chatid

alias_permitidos = {}
alias_desconoidentificacionos = []

commands = {
	    'inicio': 'Activacion bot',
        'ayuda': 'Comandos ejecutables',
        'mecool': 'Sistema operativo mecool',
        'meminfo': 'Informacion memoria mecool',
        'oscamlog': 'Ver informacion log oscam',
        'reboot': 'Reinicia mecool',
        'reTvh': 'Reinicia el servicio tvheadend',
        'reoscam': 'Reinicia el servicio oscam',
        'stopkodi': 'Para el servicio kodi',
        'startkodi': 'Inicia el servicio kodi',
        'zerotier': 'Informacion estado zerotier',
        'temp': 'Temperatura mecool',
	    'cpu': 'Carga de la CPU',
	    'ippublicamecool': 'Ip publica mecool',
        'canal': 'Captura canal que estamos visionando',
        'Actualizacioncanales': 'Actualiza canales koala',
	    
}


def inicio_alias(uid):
    if uid in alias_permitidos:
        return alias_permitidos[uid]
    else:
        alias_desconoidentificacionos.append(uid)
        alias_permitidos[uid] = 0

def listener(messages):
    for m in messages:
        if m.content_type == 'text':
            print("mensaje enviado")

bot = telebot.TeleBot(BOT_TOKEN)
bot.set_update_listener(listener)


@bot.message_handler(commands=['inicio'])
def command_inicio(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
      alias_permitidos[identificacion] = 0
      time.sleep(1)
      bot.send_message(identificacion, "Ejecute /ayuda para ver los comandos que se pueden usar en nuestro receptor Mecool\n")
    else:
        bot.send_message(identificacion, " ¡¡ESTA USANDO UN BOT NO PERMITIDO!!")

@bot.message_handler(commands=['ayuda'])
def command_ayuda(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
      
      bot.send_message(identificacion, "/ayuda muestra los comandos disponibles\n"
          "/inicio Inicia el bot\n"
          "/mecool Muestra Sistema operativo mecool\n"
          "/meminfo Informacion memoria mecool\n"
          "/ippublicamecool ip publica mecool\n"
          "/oscamlog Muestra ultimas lineas log oscam\n"
          "/canal Captura de imagen del receptor\n"
          "/zerotier Informacion estado zerotier\n"
          "/reboot Reinicia completo de mecool\n"
          "/Actualizacioncanales Actualiza lista canales Koala en caso novedades\n"
          "/reTvh Reinicia tvheadend\n"
          "/reoscam Reinicia oscam\n"
          "/stopkodi Paramos el servicio kodi\n"
          "/startkodi iniciamos el servicio kodi\n"
          "/temp Temperatura mecool\n"
	      "/cpu Carga de la CPU\n")
    else:
        bot.send_message(identificacion, " ¡¡PERMISO DENEGADO!!")


@bot.message_handler(commands=['mecool'])
def command_osmecool(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
        tempFile = open( "/etc/os-release" )
        osmecool = tempFile.read()
        tempFile.close()
        bot.send_message(identificacion, osmecool)
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")
        print(color.RED + " ¡¡NO TIENE PERMISO!! " + color.ENDC)

@bot.message_handler(commands=['meminfo'])
def command_meninfo(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       ram_all = os.popen('cat /proc/meminfo')
       result = ram_all.read()
       bot.send_message(identificacion, "[+] INFORMACION MEMORIA")
       bot.send_message(identificacion, result)
       
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")

@bot.message_handler(commands=['oscamlog'])
def command_oscamlog(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       oscam_log = os.popen('cat /storage/.kodi/userdata/addon_data/service.softcam.oscam/log/oscam.log')
       for textline in oscam_log.readlines()[20:]:
           bot.send_message(identificacion, "[+] INFORMACION LOG OSCAM")
           bot.send_message(identificacion, textline)
       
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")


@bot.message_handler(commands=['reboot'])
def command_reboot(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       reboot = os.system('reboot')
       bot.send_message(identificacion, reboot)
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")
        print(color.RED + " ¡¡NO TIENE PERMISO!! " + color.ENDC)

@bot.message_handler(commands=['reTvh'])
def command_reTvh(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       rtvh = os.system('systemctl restart service.tvheadend42.service')
       bot.send_message(identificacion, rtvh)
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")
        print(color.RED + " ¡¡NO TIENE PERMISO!! " + color.ENDC)

@bot.message_handler(commands=['stopkodi'])
def command_stopkodi(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       stop = os.system('systemctl stop kodi')
       bot.send_message(identificacion, stop)
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")
        print(color.RED + " ¡¡NO TIENE PERMISO!! " + color.ENDC)

@bot.message_handler(commands=['startkodi'])
def command_startkodi(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       start = os.system('systemctl start kodi')
       bot.send_message(identificacion, start)
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")
        print(color.RED + " ¡¡NO TIENE PERMISO!! " + color.ENDC)


@bot.message_handler(commands=['reoscam'])
def command_reoscam(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       reoscam = os.system('service.softcam.oscam.service')
       bot.send_message(identificacion, reoscam)
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")
        print(color.RED + " ¡¡NO TIENE PERMISO!! " + color.ENDC)

@bot.message_handler(commands=['zerotier'])
def command_zerotier(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       bot.send_message(identificacion, "[+] INFORMACION ZEROTIER")
       # estado zerotier
       estado = os.popen('/storage/.opt/bin/zerotier-cli info')
       result = estado.read()
       bot.send_message(identificacion, "  [i] " + result)
       # per zerotier
       peer = os.popen('/storage/.opt/bin/zerotier-cli listpeers')
       result = peer.read()
       bot.send_message(identificacion, "  [i] " + result)
       # network zerotier
       network = os.popen('/storage/.opt/bin/zerotier-cli listnetworks')
       result = network.read()
       bot.send_message(identificacion, "  [i] " + result)
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")



@bot.message_handler(commands=['temp'])
def command_temp(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
       bot.send_message(identificacion, "[+] TEMPERATURAS")
       # cpu temp
       tempFile = open( "/sys/class/thermal/thermal_zone0/temp" )
       cpu_temp = tempFile.read()
       tempFile.close()
       cpu_temp = round(float(cpu_temp)/1000)
       bot.send_message(identificacion, "  [i]   CPU: %s" % cpu_temp)
       
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")

@bot.message_handler(commands=['cpu'])
def command_cpu(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
        bot.send_message(identificacion, "[+] CPU")
        cpu = os.popen('mpstat | grep -A 5 "%idle" | tail -n 1 | awk -F " " \'{print 100 - $ 12}\'a').read()
        bot.send_message(identificacion, "  [i]   Usado: %s" % cpu)
    else:
       bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")

@bot.message_handler(commands=['ippublicamecool'])
def command_ippublicamecool(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
        ipmecool = os.popen('curl ifconfig.me')
        bot.send_message(identificacion, ipmecool)
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")

@bot.message_handler(commands=['canal'])
def command_foto(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
        captura = os.system('rm -r /storage/screenshots/* && /usr/bin/kodi-send --action="TakeScreenshot" && sleep 5')
        bot.send_message(identificacion, 'Realizando captura espere...', captura)
        bot.send_photo(identificacion, photo=open('/storage/screenshots/screenshot000.png', 'rb'))
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")
        print(color.RED + " ¡¡NO TIENE PERMISO!! " + color.ENDC)

@bot.message_handler(commands=['Actualizacioncanales'])
def command_Actualizacioncanales(m):
    identificacion = m.chat.id
    if identificacion == CHAT_ID :
        actualizacion = os.system("""

actualizacion=`cat /storage/koala_version.txt 2>/dev/null`
instalada=`curl -s https://raw.githubusercontent.com/koala-mecool/koala-EPG/master/version_actualizacion.txt 2>/dev/null`
Actualizacion_individual='https://raw.githubusercontent.com/koala-mecool/koala-EPG/master/individual/actualizacion_canales/actualizacion_koala.tar.gz'



if [ "$actualizacion" != "$instalada" ]; then
	echo "hay actualizaciones"
    wget $Actualizacion_individual -P /storage
    systemctl stop service.tvheadend42
    tar -xzvf /storage/actualizacion_koala.tar.gz -C /storage
    rm -r /storage/actualizacion_koala.tar.gz
    systemctl start service.tvheadend42
    sleep 15
    kodi-send --action="Notification(AVISO,{Koala-epg Actualizado},20000,/storage/.config/script/aviso_koala.png)"
else
	echo "No existe ninguna actualizacion disponible"
fi

exit
""")
        bot.send_message(identificacion, 'Realizando test en caso necesario se actualizaran los canales...', actualizacion)
        
    else:
        bot.send_message(identificacion, " ¡¡NO TIENE PERMISO!!")
        print(color.RED + " ¡¡NO TIENE PERMISO!! " + color.ENDC)


@bot.message_handler(func=lambda message: True, content_types=['text'])
def command_text(m):
    identificacion = m.chat.id
    if (m.text.lower() in ['hola', 'hi', 'buenas', 'buenos dias']):
        bot.send_message(identificacion, 'Muy buenas, ' + str(m.from_user.first_name) + '. Me alegra verte de nuevo.')
    elif (m.text.lower() in ['adios', 'aios', 'adeu', 'ciao']):
        bot.send_message(identificacion, 'Hasta luego, ' + str(m.from_user.first_name) + '. Te echaré de menos.')


print ('boot koala esta funcionando...')
bot.polling(none_stop=True)

