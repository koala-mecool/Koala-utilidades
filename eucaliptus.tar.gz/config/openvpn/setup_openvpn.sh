#!/bin/sh

# Script para crear certificados cliente y servidor para mecool
#
# Mas informacion visite https://t.me/mecoolki_ayuda
export OPENVPN_DIR="/storage/.config/openvpn"
export ANDROID_DIR="/storage/.config/openvpn/client1-android"
export IPAD_DIR="/storage/.config/openvpn/client2-ipad"
export PC_LIN="/storage/.config/openvpn/client3-pc_lin"


echo "Extracción de archivos de instalación..."

tar -xvf openvpn-2.4.3.tar.gz
cp -r openvpn-2.4.3/easy-rsa ./
cd easy-rsa/2.0/

chmod 777 *

# Change region file vars
sed -i 's/"US"/ES/g' "vars"
sed -i 's/"CA"/MA/g' "vars"
sed -i 's/"SanFrancisco"/Madrid/g' "vars"
sed -i 's/"Fort-Funston"/koala/g' "vars"

# Finally change region

# Fix create client no change
sed -i 's/export KEY_CN=changeme/#export KEY_CN=changeme/g' "vars"
sed -i 's/export KEY_NAME=changeme/#export KEY_NAME=changeme/g' "vars"
sed -i 's/export KEY_OU=changeme/#export KEY_OU=changeme/g' "vars"
sed -i 's/export PKCS11_MODULE_PATH=changeme/#export PKCS11_MODULE_PATH=changeme/g' "vars"
sed -i 's/export PKCS11_PIN=1234/#export PKCS11_PIN=1234/g' "vars"

source ./vars
./clean-all
./pkitool --initca
./pkitool --server server
./pkitool client1
./pkitool client2
./pkitool client3

./build-dh


mkdir $ANDROID_DIR
mkdir $IPAD_DIR
mkdir $PC_LIN

mv keys $OPENVPN_DIR

cd ..
cd ..
echo ""
echo ""
echo ""
echo ""
echo ""
echo "Incorporación de certs y claves dentro del archivo client.ovpn para tener todo en 1"


echo -e "\n\n<ca>\n$(cat keys/ca.crt)\n</ca>" >> "${ANDROID_DIR}/client.ovpn"
echo -e "\n\n<cert>\n$(cat keys/client1.crt)\n</cert>" >> "${ANDROID_DIR}/client.ovpn"
echo -e "\n\n<key>\n$(cat keys/client1.key)\n</key>" >> "${ANDROID_DIR}/client.ovpn"

echo -e "\n\n<ca>\n$(cat keys/ca.crt)\n</ca>" >> "${IPAD_DIR}/client.ovpn"               
echo -e "\n\n<cert>\n$(cat keys/client2.crt)\n</cert>" >> "${IPAD_DIR}/client.ovpn"       
echo -e "\n\n<key>\n$(cat keys/client2.key)\n</key>" >> "${IPAD_DIR}/client.ovpn"         

echo -e "\n\n<ca>\n$(cat keys/ca.crt)\n</ca>" >> "${PC_LIN}/client.ovpn"               
echo -e "\n\n<cert>\n$(cat keys/client3.crt)\n</cert>" >> "${PC_LIN}/client.ovpn"       
echo -e "\n\n<key>\n$(cat keys/client3.key)\n</key>" >> "${PC_LIN}/client.ovpn"

rm -r openvpn-2.4.3
rm -r openvpn-2.4.3.tar.gz
rm -r easy-rsa
rm -r setup_openvpn.sh


echo ""
echo ""
echo ""
echo "Todo Listo!"
echo "Se ha configurado el servidor y se han generado las configuraciones del cliente visite https://t.me/mecoolki_ayuda para mas informacion"

